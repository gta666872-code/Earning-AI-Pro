# Earning AI Pro – Android Starter

यह शुरुआती Android ऐप है। इसमें:
- Remote/freelance काम खोजने के लिए browser search shortcuts
- अपने काम की सूची बनाना और पूरा करना
- वास्तविक प्राप्त कमाई दर्ज करना
- डेटा फोन में SharedPreferences में सेव करना

## APK बनाना (GitHub Actions)
1. इस ZIP को Extract करें।
2. Extract किए गए फ़ोल्डर के अंदर की सभी फाइलें और फ़ोल्डर `gta666872-code/A-AI` repository के `main` branch के root में upload करें।
3. `.github/workflows/build-apk.yml` सहित सभी फाइलें upload हों।
4. GitHub में Actions खोलें।
5. `Build Earning AI Pro APK` workflow चुनें और `Run workflow` दबाएँ (या push के बाद अपने आप चलेगा)।
6. सफल run खोलें। नीचे Artifacts में `Earning-AI-Pro-debug-apk` डाउनलोड करें।
7. ZIP artifact को फोन में Extract करें। `app-debug.apk` खोलकर install करें। Android पूछे तो इस स्रोत से install की अनुमति दें।

## जरूरी सीमाएँ
यह v1 starter है, पूर्ण स्वायत्त AI नहीं। अभी यह नौकरी खोजने के लिए browser खोलता है और task/income tracking करता है। वास्तविक AI reasoning, authenticated website automation, company applications और payment integrations के लिए अलग backend/API, user authorization, platform terms compliance और सुरक्षित credential handling जोड़ना होगा। ऐप किसी नौकरी या कमाई की गारंटी नहीं देता।
