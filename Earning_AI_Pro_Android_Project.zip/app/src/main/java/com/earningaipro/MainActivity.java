package com.earningaipro;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(12, 18, 32);
    private final int panel = Color.rgb(25, 35, 55);
    private final int green = Color.rgb(66, 211, 146);
    private LinearLayout content;
    private SharedPreferences prefs;
    private ArrayList<String> tasks = new ArrayList<>();
    private double income = 0;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("earning_ai", MODE_PRIVATE);
        income = Double.longBitsToDouble(prefs.getLong("income", Double.doubleToLongBits(0)));
        loadTasks();
        buildUi();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, 1);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(14), dp(16), dp(14));
        box.setBackgroundColor(panel);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(12));
        box.setLayoutParams(lp);
        return box;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(14);
        return b;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(24), dp(18), dp(24));
        scroll.addView(content);
        setContentView(scroll);

        content.addView(text("EARNING AI PRO", 13, green, true));
        content.addView(text("आपका Personal Work Agent", 25, Color.WHITE, true));
        content.addView(text("काम खोजें • काम व्यवस्थित करें • कमाई ट्रैक करें", 13, Color.LTGRAY, false));

        LinearLayout summary = card();
        summary.addView(text("आज की दर्ज कमाई", 14, Color.LTGRAY, false));
        TextView total = text(String.format(Locale.US, "₹%.2f", income), 30, green, true);
        summary.addView(total);
        summary.addView(text("यह आपकी दर्ज की गई कमाई है, अनुमान या गारंटी नहीं।", 11, Color.LTGRAY, false));
        content.addView(summary);

        LinearLayout jobs = card();
        jobs.addView(text("1. ऑनलाइन काम खोजें", 18, Color.WHITE, true));
        jobs.addView(text("कंपनियों और फ्रीलांस प्लेटफॉर्म पर अवसर खोजने के लिए ब्राउज़र खुलेगा। आवेदन भेजने से पहले विवरण जाँचें।", 13, Color.LTGRAY, false));
        Button jobBtn = button("काम / Remote Jobs खोजें");
        jobBtn.setOnClickListener(v -> openSearch("remote data entry jobs India freelance AI training Hindi English"));
        jobs.addView(jobBtn);
        Button freelanceBtn = button("Freelance Projects खोजें");
        freelanceBtn.setOnClickListener(v -> openSearch("freelance Excel data entry graphic design projects"));
        jobs.addView(freelanceBtn);
        content.addView(jobs);

        LinearLayout agent = card();
        agent.addView(text("2. Work Agent", 18, Color.WHITE, true));
        agent.addView(text("अभी यह शुरुआती संस्करण आपके काम और टास्क व्यवस्थित करता है। वास्तविक AI वेबसाइट-ऑटोमेशन के लिए सुरक्षित AI/API कनेक्शन अगले चरण में जोड़ा जाएगा।", 13, Color.LTGRAY, false));
        Button addTask = button("＋ नया काम जोड़ें");
        addTask.setOnClickListener(v -> addTaskDialog());
        agent.addView(addTask);
        content.addView(agent);

        LinearLayout earnings = card();
        earnings.addView(text("3. कमाई दर्ज करें", 18, Color.WHITE, true));
        Button addIncome = button("＋ कमाई जोड़ें");
        addIncome.setOnClickListener(v -> addIncomeDialog());
        earnings.addView(addIncome);
        content.addView(earnings);

        renderTasks();
        LinearLayout safety = card();
        safety.addView(text("सुरक्षा और नियंत्रण", 16, Color.WHITE, true));
        safety.addView(text("यह ऐप बिना आपकी जानकारी के किसी कंपनी में आवेदन, भुगतान, OTP या अकाउंट सत्यापन नहीं करता। पासवर्ड/API key किसी को साझा न करें।", 12, Color.LTGRAY, false));
        content.addView(safety);
        content.addView(text("Earning AI Pro • Version 1.0 • Starter build", 11, Color.GRAY, false));
    }

    private void openSearch(String q) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)));
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Browser नहीं खुल पाया", Toast.LENGTH_SHORT).show();
        }
    }

    private void addTaskDialog() {
        EditText input = new EditText(this);
        input.setHint("जैसे: Excel data entry का sample बनाना");
        new AlertDialog.Builder(this)
            .setTitle("नया काम")
            .setView(input)
            .setNegativeButton("रद्द", null)
            .setPositiveButton("जोड़ें", (d, w) -> {
                String s = input.getText().toString().trim();
                if (!s.isEmpty()) {
                    tasks.add(s);
                    saveTasks();
                    buildUi();
                }
            }).show();
    }

    private void addIncomeDialog() {
        EditText input = new EditText(this);
        input.setHint("राशि रुपये में");
        input.setInputType(8194);
        new AlertDialog.Builder(this)
            .setTitle("वास्तविक प्राप्त कमाई दर्ज करें")
            .setView(input)
            .setNegativeButton("रद्द", null)
            .setPositiveButton("सेव करें", (d, w) -> {
                try {
                    double amount = Double.parseDouble(input.getText().toString().trim());
                    if (amount > 0) {
                        income += amount;
                        prefs.edit().putLong("income", Double.doubleToLongBits(income)).apply();
                        buildUi();
                    }
                } catch (Exception ex) {
                    Toast.makeText(this, "सही राशि लिखें", Toast.LENGTH_SHORT).show();
                }
            }).show();
    }

    private void renderTasks() {
        LinearLayout taskCard = card();
        taskCard.addView(text("4. आपके काम", 18, Color.WHITE, true));
        if (tasks.isEmpty()) {
            taskCard.addView(text("अभी कोई काम नहीं है। नया काम जोड़कर शुरुआत करें।", 13, Color.LTGRAY, false));
        } else {
            for (int index = 0; index < tasks.size(); index++) {
                final int ix = index;
                LinearLayout row = new LinearLayout(this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                TextView name = text("• " + tasks.get(index), 14, Color.WHITE, false);
                name.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
                row.addView(name);
                Button done = button("पूरा");
                done.setOnClickListener(v -> {
                    tasks.remove(ix);
                    saveTasks();
                    buildUi();
                    Toast.makeText(this, "काम पूरा सूची से हटाया गया", Toast.LENGTH_SHORT).show();
                });
                row.addView(done);
                taskCard.addView(row);
            }
        }
        content.addView(taskCard);
    }

    private void saveTasks() {
        StringBuilder sb = new StringBuilder();
        for (String s : tasks) sb.append(s.replace("\n", " ")).append("\n");
        prefs.edit().putString("tasks", sb.toString()).apply();
    }

    private void loadTasks() {
        String saved = prefs.getString("tasks", "");
        if (!saved.isEmpty()) {
            for (String s : saved.split("\n")) if (!s.trim().isEmpty()) tasks.add(s);
        }
    }
}
