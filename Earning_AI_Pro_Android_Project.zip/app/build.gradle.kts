plugins {
    id("com.android.application")
}

android {
    namespace = "com.earningaipro"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.earningaipro"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
